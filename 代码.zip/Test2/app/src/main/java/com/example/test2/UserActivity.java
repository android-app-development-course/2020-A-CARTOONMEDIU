package com.example.test2;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;
import com.bumptech.glide.request.RequestOptions;

import jp.wasabeef.glide.transformations.BlurTransformation;
import jp.wasabeef.glide.transformations.CropCircleTransformation;


public class UserActivity extends AppCompatActivity {
    private ImageView blurImageView;
    private ImageView avatarImageView;

    private item_view collection;
    private item_view results;
    private item_view version;
    private item_view logout;
    private item_view main;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);//去掉标题栏
        setContentView(R.layout.main_layout);
        blurImageView = (ImageView) findViewById(R.id.iv_blur);
        avatarImageView = (ImageView) findViewById(R.id.iv_avatar);
        version = (item_view)findViewById(R.id.version);
        logout = (item_view)findViewById(R.id.logout);
        main = (item_view)findViewById(R.id.main);

        Glide.with(this).load(R.drawable.head)
                .apply(RequestOptions.bitmapTransform(new BlurTransformation(25, 3)))
                .into(blurImageView);

        Glide.with(this).load(R.drawable.head)
                .apply(RequestOptions.bitmapTransform(new CropCircleTransformation()))
                .into(avatarImageView);



        main.setOnClickListener(v -> {
            Toast.makeText(this, "main", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(this, MainActivity.class);
            startActivity(it);
        });

        version.setOnClickListener(v -> {
            Toast.makeText(this, "version", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(this, banbengengxin.class);
            startActivity(it);
        });



        logout.setOnClickListener(v -> {
            Toast.makeText(this, "logout", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(this,LoginActivity.class);
            startActivity(it);
        });
    }
}
