package com.example.test2;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class banbengengxin extends AppCompatActivity {
    ImageButton b;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.banbengengxin);
        b =findViewById(R.id.back);
        b.setOnClickListener(v -> {
            Toast.makeText(this, "main", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(this, UserActivity.class);
            startActivity(it);
        });
    }
}
