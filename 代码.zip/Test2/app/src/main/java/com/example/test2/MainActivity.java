package com.example.test2;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.yanzhenjie.album.Action;
import com.yanzhenjie.album.AlbumFile;
import com.yanzhenjie.album.AlbumLoader;


import java.util.ArrayList;
import java.util.List;

import com.yanzhenjie.album.Album;
import com.yanzhenjie.album.AlbumConfig;

public class MainActivity extends AppCompatActivity {
    private ImageView blurImageView;
    private ImageView avatarImageView;


    ImageButton cam,user;
    public void tiaozhuan()
    {
        Intent it = new Intent(this, Third.class);
        startActivity(it);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Album.initialize(
                AlbumConfig.newBuilder(this)
                        .setAlbumLoader(AlbumLoader.DEFAULT).build()

        );


        cam =findViewById(R.id.btncam);
        cam.setOnClickListener(v -> {
            Toast.makeText(this, "打开相机", Toast.LENGTH_SHORT).show();

            Album.image(this)
                    .singleChoice()
                    .camera(true)
                    .columnCount(3)
                    .onResult(new Action<ArrayList<AlbumFile>>() {

                        @Override
                        public void onAction(@NonNull ArrayList<AlbumFile> result) {
                            if (result.size() > 0) {
                                tiaozhuan();
                            }
                        }
                    })
                    .onCancel(new Action<String>() {
                        @Override
                        public void onAction(@NonNull String result) {
                        }
                    })
                    .start();
        });

        user =findViewById(R.id.btnuser);
        user.setOnClickListener(v -> {
            Toast.makeText(this, "打开个人中心", Toast.LENGTH_SHORT).show();
            Intent it = new Intent(this, UserActivity.class);
            startActivity(it);
        });



        List images = new ArrayList();
        images.add(R.drawable.a);
        images.add(R.drawable.b);
        images.add(R.drawable.c);




        

    }


}